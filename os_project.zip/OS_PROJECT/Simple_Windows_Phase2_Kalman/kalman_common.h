#include "os_wrapper.h"
#include "kalman.h"

int read_all(os_fd fd, void* buf, long n) {
    char* p = (char*)buf;
    long done = 0;
    while (done < n) {
        long want = n - done;
        if (want > 1048576) want = 1048576;
        long got = os_read(fd, p + done, want);
        if (got <= 0) return -1;
        done += got;
    }
    return 0;
}

int write_all(os_fd fd, const void* buf, long n) {
    const char* p = (const char*)buf;
    long done = 0;
    while (done < n) {
        long want = n - done;
        if (want > 1048576) want = 1048576;
        long put = os_write(fd, p + done, want);
        if (put <= 0) return -1;
        done += put;
    }
    return 0;
}

struct Job {
    const double* meas;
    double* out;
    int n;
    int first;
    int last;
    double dt, q, r;
};

DWORD WINAPI thread_main(LPVOID arg) {
    Job* job = (Job*)arg;
    filter_range(job->meas, job->out, job->n, job->first, job->last, job->dt, job->q, job->r);
    return 0;
}

void run_threads(const double* meas, double* out, int n, int first, int last, int threads, double dt, double q, double r) {
    if (threads <= 1) {
        filter_range(meas, out, n, first, last, dt, q, r);
        return;
    }
    if (threads > 16) threads = 16;
    Job jobs[16];
    os_thread t[16];
    int count = last - first;
    for (int i = 0; i < threads; i++) {
        jobs[i].meas = meas;
        jobs[i].out = out;
        jobs[i].n = n;
        jobs[i].first = first + count * i / threads;
        jobs[i].last = first + count * (i + 1) / threads;
        jobs[i].dt = dt;
        jobs[i].q = q;
        jobs[i].r = r;
        os_thread_create(thread_main, &jobs[i], &t[i]);
    }
    for (int i = 0; i < threads; i++)
        os_thread_join(t[i]);
}
