#include "kalman_common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {
    if (argc < 4) return 2;
    int key = atoi(argv[1]);
    int id = atoi(argv[2]);
    os_fd pipe_end = (os_fd)(long long)atoll(argv[3]);

    char log_name[50];
    sprintf(log_name, "worker_%d_log.csv", id);
    os_log_open(log_name);

    os_shm shm;
    if (os_shm_open(key, 0, 0, &shm) != 0) return 3;
    double* settings = (double*)shm.addr;
    int vehicles = (int)settings[0];
    int steps = (int)settings[1];
    double sigma = settings[2];
    double accel = settings[3];
    int threads = (int)settings[4];
    int workers = (int)settings[5];
    double* meas = settings + 8;
    double* out = meas + (long)vehicles * steps * 2;

    int first = vehicles * id / workers;
    int last = vehicles * (id + 1) / workers;

    long long start = os_now_ns();
    run_threads(meas, out, steps, first, last, threads, 1.0, accel * accel, sigma * sigma);
    double ms = (os_now_ns() - start) / 1000000.0;

    char message[200];
    sprintf(message, "worker %d: vehicles %d to %d done in %.1f ms\n", id, first, last - 1, ms);
    os_write(pipe_end, message, strlen(message));
    os_close(pipe_end);
    os_shm_close(&shm, 0);
    os_log_close();
    return 0;
}
