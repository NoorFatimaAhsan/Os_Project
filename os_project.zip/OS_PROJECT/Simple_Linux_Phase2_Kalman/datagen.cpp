#include "kalman_common.h"
#include <stdio.h>
#include <stdlib.h>

unsigned int state;

double random01() {
    state = state * 1664525u + 1013904223u;
    return (state >> 8) / 16777216.0;
}

double gauss() {
    double sum = 0;
    for (int i = 0; i < 12; i++) sum += random01();
    return sum - 6.0;
}

int main(int argc, char* argv[]) {
    if (argc < 7) {
        printf("usage: datagen vehicles steps sensor_noise accel_noise seed file\n");
        return 1;
    }
    int vehicles = atoi(argv[1]);
    int steps = atoi(argv[2]);
    double sigma = atof(argv[3]);
    double accel = atof(argv[4]);
    state = (unsigned int)atoi(argv[5]);
    const char* file_name = argv[6];

    os_log_open("datagen_log.csv");
    long bytes = (long)vehicles * steps * 2 * sizeof(double);
    double* meas = (double*)os_mem_alloc(bytes);
    double* truth = (double*)os_mem_alloc(bytes);
    if (meas == NULL || truth == NULL) { printf("not enough memory\n"); return 1; }

    for (int v = 0; v < vehicles; v++) {
        double px = random01() * 1000, py = random01() * 1000;
        double vx = (random01() - 0.5) * 20, vy = (random01() - 0.5) * 20;
        for (int s = 0; s < steps; s++) {
            long i = ((long)v * steps + s) * 2;
            double ax = gauss() * accel, ay = gauss() * accel;
            px = px + vx + 0.5 * ax;  py = py + vy + 0.5 * ay;
            vx = vx + ax;             vy = vy + ay;
            truth[i] = px;            truth[i + 1] = py;
            meas[i] = px + gauss() * sigma;  meas[i + 1] = py + gauss() * sigma;
        }
    }

    double head[4] = { (double)vehicles, (double)steps, sigma, accel };
    os_fd f = os_open(file_name, OS_WRITE);
    if (f == OS_BAD_FD) { printf("cannot create %s\n", file_name); return 1; }
    write_all(f, head, sizeof(head));
    write_all(f, meas, bytes);
    write_all(f, truth, bytes);
    os_close(f);

    os_mem_free(meas, bytes);
    os_mem_free(truth, bytes);
    os_log_close();
    printf("created %s: %d vehicles x %d steps, %.1f MB\n", file_name, vehicles, steps, (sizeof(head) + 2.0 * bytes) / 1048576.0);
    return 0;
}
