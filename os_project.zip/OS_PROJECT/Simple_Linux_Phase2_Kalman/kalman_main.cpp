#include "kalman_common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(int argc, char* argv[]) {
    const char* in_name = "sensors.bin";
    const char* out_name = "kalman_out.bin";
    const char* mode = "seq";
    int procs = 1;
    int threads = 1;
    for (int i = 1; i < argc - 1; i++) {
        if (strcmp(argv[i], "--mode") == 0)    mode = argv[i + 1];
        if (strcmp(argv[i], "--procs") == 0)   procs = atoi(argv[i + 1]);
        if (strcmp(argv[i], "--threads") == 0) threads = atoi(argv[i + 1]);
        if (strcmp(argv[i], "--in") == 0)      in_name = argv[i + 1];
        if (strcmp(argv[i], "--out") == 0)     out_name = argv[i + 1];
    }
    int use_procs = strcmp(mode, "procs") == 0;
    if (strcmp(mode, "seq") == 0) threads = 1;
    if (procs > 16) procs = 16;
    if (!use_procs) procs = 1;

    os_umask(077);
    os_log_open("kalman_main_log.csv");
    long long t_start = os_now_ns();

    os_fd f = os_open(in_name, OS_READ);
    if (f == OS_BAD_FD) { printf("cannot open %s\n", in_name); return 1; }
    double head[4];
    if (read_all(f, head, sizeof(head)) != 0) { printf("bad file\n"); return 1; }
    int vehicles = (int)head[0];
    int steps = (int)head[1];
    double sigma = head[2];
    double accel = head[3];
    long count = (long)vehicles * steps * 2;
    long bytes = count * sizeof(double);

    os_shm shm;
    double* meas;
    double* out;
    int key = 100000 + (int)((os_now_ns() / 1000) % 800000);
    if (use_procs) {
        if (os_shm_open(key, 8 * sizeof(double) + 2 * bytes, 1, &shm) != 0) { printf("shared memory failed\n"); return 1; }
        double* settings = (double*)shm.addr;
        settings[0] = vehicles;
        settings[1] = steps;
        settings[2] = sigma;
        settings[3] = accel;
        settings[4] = threads;
        settings[5] = procs;
        meas = settings + 8;
        out = meas + count;
    } else {
        meas = (double*)os_mem_alloc(bytes);
        out = (double*)os_mem_alloc(bytes);
    }
    double* truth = (double*)os_mem_alloc(bytes);
    if (meas == NULL || out == NULL || truth == NULL) { printf("not enough memory\n"); return 1; }

    if (read_all(f, meas, bytes) != 0 || read_all(f, truth, bytes) != 0) { printf("file too short\n"); return 1; }
    os_close(f);
    long long t_read = os_now_ns();

    double dt = 1.0;
    double q = accel * accel;
    double r = sigma * sigma;
    if (!use_procs) {
        run_threads(meas, out, steps, 0, vehicles, threads, dt, q, r);
    } else {
        os_fd pipe_read, pipe_write;
        os_pipe_create(&pipe_read, &pipe_write);
        char key_text[20], pipe_text[20], id_text[20];
        sprintf(key_text, "%d", key);
        sprintf(pipe_text, "%d", pipe_write);
        int pids[16];
        for (int w = 0; w < procs; w++) {
            sprintf(id_text, "%d", w);
            pids[w] = os_spawn("./kalman_worker", key_text, id_text, pipe_text);
            if (pids[w] < 0) printf("could not start worker %d\n", w);
        }
        os_close(pipe_write);
        for (int w = 0; w < procs; w++)
            if (pids[w] > 0) os_wait(pids[w]);
        char buf[256];
        long n = os_read(pipe_read, buf, 255);
        while (n > 0) {
            buf[n] = 0;
            printf("%s", buf);
            n = os_read(pipe_read, buf, 255);
        }
        os_close(pipe_read);
    }
    long long t_filter = os_now_ns();

    os_fd o = os_open(out_name, OS_WRITE);
    write_all(o, head, sizeof(head));
    write_all(o, out, bytes);
    os_close(o);
    os_chmod(out_name, 0600);
    os_chown(out_name, -1, -1);
    long long t_write = os_now_ns();

    double total_ms = (t_write - t_start) / 1000000.0;
    double read_ms = (t_read - t_start) / 1000000.0;
    double filter_ms = (t_filter - t_read) / 1000000.0;
    double write_ms = (t_write - t_filter) / 1000000.0;

    double sum_raw = 0, sum_filtered = 0;
    for (long i = 0; i < count; i += 2) {
        double rx = meas[i] - truth[i], ry = meas[i + 1] - truth[i + 1];
        double fx = out[i] - truth[i],  fy = out[i + 1] - truth[i + 1];
        sum_raw += rx * rx + ry * ry;
        sum_filtered += fx * fx + fy * fy;
    }
    double points = count / 2.0;
    double error_raw = sqrt(sum_raw / points);
    double error_filtered = sqrt(sum_filtered / points);

    double cpu_user, cpu_sys;
    long peak_kb;
    os_resource_usage(&cpu_user, &cpu_sys, &peak_kb);

    char text[1000];
    int len = sprintf(text,
        "mode=%s processes=%d threads=%d\n"
        "vehicles=%d steps=%d sensor_noise=%.2f\n"
        "read_ms=%.2f filter_ms=%.2f write_ms=%.2f total_ms=%.2f\n"
        "error before filter = %.3f\n"
        "error after filter  = %.3f\n"
        "cpu_user_ms=%.1f cpu_sys_ms=%.1f peak_memory_kb=%ld\n",
        mode, procs, threads, vehicles, steps, sigma, read_ms, filter_ms, write_ms, total_ms,
        error_raw, error_filtered, cpu_user, cpu_sys, peak_kb);
    os_fd s = os_open("kalman_summary.txt", OS_WRITE);
    os_write(s, text, len);
    os_close(s);

    FILE* sample = fopen("kalman_sample.csv", "w");
    fprintf(sample, "step,raw_x,raw_y,filtered_x,filtered_y,true_x,true_y\n");
    for (int t = 0; t < steps && t < 300; t++)
        fprintf(sample, "%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\n", t, meas[2 * t], meas[2 * t + 1],
                out[2 * t], out[2 * t + 1], truth[2 * t], truth[2 * t + 1]);
    fclose(sample);

    FILE* results = fopen("kalman_results_linux.csv", "a");
    fseek(results, 0, SEEK_END);
    if (ftell(results) == 0)
        fprintf(results, "os,mode,procs,threads,vehicles,steps,total_ms,read_ms,filter_ms,write_ms,error_raw,error_filtered,cpu_user_ms,cpu_sys_ms,peak_mem_kb\n");
    fprintf(results, "linux,%s,%d,%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.3f,%.3f,%.1f,%.1f,%ld\n", mode, procs, threads,
            vehicles, steps, total_ms, read_ms, filter_ms, write_ms, error_raw, error_filtered, cpu_user, cpu_sys, peak_kb);
    fclose(results);

    printf("%s procs=%d threads=%d: total %.1f ms (read %.1f, filter %.1f, write %.1f), error %.3f -> %.3f\n",
           mode, procs, threads, total_ms, read_ms, filter_ms, write_ms, error_raw, error_filtered);

    os_mem_free(truth, bytes);
    if (use_procs) {
        os_shm_close(&shm, 1);
    } else {
        os_mem_free(meas, bytes);
        os_mem_free(out, bytes);
    }
    os_log_close();
    return 0;
}
