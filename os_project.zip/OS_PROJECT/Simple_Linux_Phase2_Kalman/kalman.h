void filter_one_vehicle(const double* z, double* out, int n, double dt, double q, double r) {
    double F[4][4] = { {1, dt, 0, 0},
                       {0, 1,  0, 0},
                       {0, 0,  1, dt},
                       {0, 0,  0, 1} };
    double q4 = q * dt * dt * dt * dt / 4;
    double q3 = q * dt * dt * dt / 2;
    double q2 = q * dt * dt;
    double Q[4][4] = { {q4, q3, 0,  0},
                       {q3, q2, 0,  0},
                       {0,  0,  q4, q3},
                       {0,  0,  q3, q2} };

    double x[4] = { z[0], 0, z[1], 0 };
    double P[4][4] = { {r, 0, 0, 0},
                       {0, 100, 0, 0},
                       {0, 0, r, 0},
                       {0, 0, 0, 100} };
    out[0] = z[0];
    out[1] = z[1];

    for (int step = 1; step < n; step++) {
        x[0] = x[0] + dt * x[1];
        x[2] = x[2] + dt * x[3];

        double T[4][4];
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++) {
                T[i][j] = 0;
                for (int k = 0; k < 4; k++) T[i][j] += F[i][k] * P[k][j];
            }
        double P2[4][4];
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++) {
                P2[i][j] = Q[i][j];
                for (int k = 0; k < 4; k++) P2[i][j] += T[i][k] * F[j][k];
            }

        double diff_x = z[2 * step]     - x[0];
        double diff_y = z[2 * step + 1] - x[2];

        double s00 = P2[0][0] + r, s01 = P2[0][2];
        double s10 = P2[2][0],     s11 = P2[2][2] + r;
        double det = s00 * s11 - s01 * s10;
        double i00 =  s11 / det, i01 = -s01 / det;
        double i10 = -s10 / det, i11 =  s00 / det;

        double K[4][2];
        for (int i = 0; i < 4; i++) {
            K[i][0] = P2[i][0] * i00 + P2[i][2] * i10;
            K[i][1] = P2[i][0] * i01 + P2[i][2] * i11;
        }
        for (int i = 0; i < 4; i++)
            x[i] = x[i] + K[i][0] * diff_x + K[i][1] * diff_y;
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                P[i][j] = P2[i][j] - (K[i][0] * P2[0][j] + K[i][1] * P2[2][j]);

        out[2 * step]     = x[0];
        out[2 * step + 1] = x[2];
    }
}

void filter_range(const double* meas, double* out, int n, int first, int last, double dt, double q, double r) {
    for (int v = first; v < last; v++) {
        long start = (long)v * n * 2;
        filter_one_vehicle(meas + start, out + start, n, dt, q, r);
    }
}
