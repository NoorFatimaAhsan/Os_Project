#include <stdio.h>
#include <string.h>

const char* task_name(const char* call) {
    if (!strcmp(call, "open") || !strcmp(call, "CreateFile")) return "file_open";
    if (!strcmp(call, "read") || !strcmp(call, "ReadFile")) return "file_read";
    if (!strcmp(call, "write") || !strcmp(call, "WriteFile")) return "file_write";
    if (!strcmp(call, "close") || !strcmp(call, "CloseHandle")) return "file_close";
    if (!strcmp(call, "fork") || !strcmp(call, "CreateProcess")) return "process_create";
    if (!strcmp(call, "exec")) return "process_exec";
    if (!strcmp(call, "wait") || !strcmp(call, "WaitForSingleObject")) return "process_wait";
    if (!strcmp(call, "mmap") || !strcmp(call, "VirtualAlloc")) return "mem_alloc";
    if (!strcmp(call, "munmap") || !strcmp(call, "VirtualFree")) return "mem_free";
    if (!strcmp(call, "pipe") || !strcmp(call, "CreatePipe")) return "pipe_create";
    if (!strcmp(call, "shmget") || !strcmp(call, "CreateFileMapping") || !strcmp(call, "OpenFileMapping")) return "shm_get";
    if (!strcmp(call, "shmat") || !strcmp(call, "MapViewOfFile")) return "shm_attach";
    if (!strcmp(call, "shmdt") || !strcmp(call, "UnmapViewOfFile")) return "shm_detach";
    if (!strcmp(call, "shmctl_RMID")) return "shm_remove";
    if (!strcmp(call, "chmod") || !strcmp(call, "SetFileSecurity")) return "perm_chmod";
    if (!strcmp(call, "chown") || !strcmp(call, "SetFileSecurity(owner)")) return "perm_chown";
    if (!strcmp(call, "umask") || !strcmp(call, "umask(emulated)")) return "perm_umask";
    if (!strcmp(call, "pthread_create") || !strcmp(call, "CreateThread")) return "thread_create";
    if (!strcmp(call, "pthread_join") || !strcmp(call, "WaitForSingleObject(thread)")) return "thread_join";
    return call;
}

int is_waiting(const char* task) {
    return !strcmp(task, "process_wait") || !strcmp(task, "thread_join");
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("usage: log_summary result.csv log1.csv [log2.csv ...]\n");
        return 1;
    }
    char names[40][40];
    int calls[40] = {0};
    double total[40] = {0};
    int fails[40] = {0};
    int found = 0;
    double work_total = 0;

    for (int f = 2; f < argc; f++) {
        FILE* file = fopen(argv[f], "r");
        if (file == NULL) { printf("cannot open %s\n", argv[f]); continue; }
        char line[200];
        if (fgets(line, sizeof(line), file) == NULL) {
            fclose(file);
            continue;
        }
        while (fgets(line, sizeof(line), file) != NULL) {
            char call[60], status[10];
            double time_us;
            if (sscanf(line, "%59[^,],%9[^,],%*[^,],%*[^,],%lf", call, status, &time_us) != 3) continue;
            const char* task = task_name(call);
            int k = -1;
            for (int i = 0; i < found; i++)
                if (strcmp(names[i], task) == 0) k = i;
            if (k < 0 && found < 40) {
                k = found;
                strncpy(names[k], task, 39);
                names[k][39] = 0;
                found++;
            }
            if (k < 0) continue;
            calls[k]++;
            total[k] += time_us;
            if (strcmp(status, "OK") != 0) fails[k]++;
            if (!is_waiting(task)) work_total += time_us;
        }
        fclose(file);
    }

    int order[40];
    for (int i = 0; i < found; i++) order[i] = i;
    for (int i = 0; i < found; i++)
        for (int j = 0; j + 1 < found - i; j++)
            if (total[order[j]] < total[order[j + 1]]) {
                int tmp = order[j]; order[j] = order[j + 1]; order[j + 1] = tmp;
            }

    FILE* out = fopen(argv[1], "w");
    fprintf(out, "task,count,total_us,mean_us,fails,share_pct\n");
    printf("%-16s %8s %12s %10s %6s %8s\n", "task", "count", "total_us", "mean_us", "fails", "share%");
    for (int i = 0; i < found; i++) {
        int k = order[i];
        double share = 0;
        if (!is_waiting(names[k]) && work_total > 0) share = 100.0 * total[k] / work_total;
        fprintf(out, "%s,%d,%.3f,%.3f,%d,%.2f\n", names[k], calls[k], total[k], total[k] / calls[k], fails[k], share);
        printf("%-16s %8d %12.1f %10.3f %6d %7.2f\n", names[k], calls[k], total[k], total[k] / calls[k], fails[k], share);
    }
    fclose(out);
    return 0;
}
