#include "os_wrapper.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[]) {
    if (argc < 2) return 2;

    if (strcmp(argv[1], "hello") == 0) {
        return 7;
    }

    os_log_open("child_log.csv");

    if (strcmp(argv[1], "pipe") == 0 && argc >= 3) {
        int fd = atoi(argv[2]);
        const char* msg = "hello from child via pipe";
        os_write(fd, msg, strlen(msg));
        os_close(fd);
        os_log_close();
        return 0;
    }

    if (strcmp(argv[1], "shm") == 0 && argc >= 4) {
        int key = atoi(argv[2]);
        int size = atoi(argv[3]);
        os_shm shm;
        if (os_shm_open(key, size, 0, &shm) != 0) {
            os_log_close();
            return 3;
        }
        strcpy((char*)shm.addr, "hello from child via shared memory");
        os_shm_close(&shm, 0);
        os_log_close();
        return 0;
    }

    os_log_close();
    return 2;
}
