#include "os_wrapper.h"
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/resource.h>

FILE* log_file = NULL;

long long os_now_ns() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

int os_log_open(const char* path) {
    log_file = fopen(path, "a");
    if (log_file == NULL) return -1;
    fseek(log_file, 0, SEEK_END);
    if (ftell(log_file) == 0)
        fprintf(log_file, "call,status,result,error,time_us\n");
    return 0;
}

void os_log_close() {
    if (log_file != NULL) {
        fclose(log_file);
        log_file = NULL;
    }
}

void write_log(const char* name, long result, long long start, long long stop) {
    if (log_file == NULL) return;
    int error = 0;
    if (result < 0) error = errno;
    fprintf(log_file, "%s,%s,%ld,%d,%.3f\n",
            name,
            result < 0 ? "FAIL" : "OK",
            result,
            error,
            (stop - start) / 1000.0);
    fflush(log_file);
}

int os_resource_usage(double* user_ms, double* sys_ms, long* peak_mem_kb) {
    struct rusage ru;
    if (getrusage(RUSAGE_SELF, &ru) != 0) return -1;
    *user_ms = ru.ru_utime.tv_sec * 1000.0 + ru.ru_utime.tv_usec / 1000.0;
    *sys_ms  = ru.ru_stime.tv_sec * 1000.0 + ru.ru_stime.tv_usec / 1000.0;
    *peak_mem_kb = ru.ru_maxrss;
    return 0;
}

os_fd os_open(const char* path, int mode) {
    int flags = O_RDONLY;
    if (mode == OS_WRITE)     flags = O_WRONLY | O_CREAT | O_TRUNC;
    if (mode == OS_APPEND)    flags = O_WRONLY | O_CREAT | O_APPEND;
    if (mode == OS_READWRITE) flags = O_RDWR | O_CREAT;

    long long start = os_now_ns();
    int fd = open(path, flags, 0644);
    long long stop = os_now_ns();
    write_log("open", fd, start, stop);
    return fd;
}

long os_read(os_fd fd, void* buf, long n) {
    long long start = os_now_ns();
    long r = read(fd, buf, n);
    long long stop = os_now_ns();
    write_log("read", r, start, stop);
    return r;
}

long os_write(os_fd fd, const void* buf, long n) {
    long long start = os_now_ns();
    long r = write(fd, buf, n);
    long long stop = os_now_ns();
    write_log("write", r, start, stop);
    return r;
}

int os_close(os_fd fd) {
    long long start = os_now_ns();
    int r = close(fd);
    long long stop = os_now_ns();
    write_log("close", r, start, stop);
    return r;
}

int os_spawn(const char* program, const char* arg1, const char* arg2, const char* arg3) {
    const char* list[5];
    int n = 0;
    list[n++] = program;
    if (arg1 != NULL) list[n++] = arg1;
    if (arg2 != NULL) list[n++] = arg2;
    if (arg3 != NULL) list[n++] = arg3;
    list[n] = NULL;

    if (log_file != NULL) fflush(log_file);

    long long start = os_now_ns();
    int pid = fork();
    if (pid == 0) {
        long long now = os_now_ns();
        write_log("exec", 0, now, now);
        execv(program, (char**)list);
        _exit(127);
    }
    long long stop = os_now_ns();
    write_log("fork", pid, start, stop);
    return pid;
}

int os_wait(int pid) {
    int status = 0;
    long long start = os_now_ns();
    int r = waitpid(pid, &status, 0);
    long long stop = os_now_ns();
    write_log("wait", r, start, stop);
    if (r < 0) return -1;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    return -1;
}

void* os_mem_alloc(long size) {
    long long start = os_now_ns();
    void* p = mmap(NULL, size, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    long long stop = os_now_ns();
    if (p == MAP_FAILED) {
        write_log("mmap", -1, start, stop);
        return NULL;
    }
    write_log("mmap", 0, start, stop);
    return p;
}

int os_mem_free(void* ptr, long size) {
    long long start = os_now_ns();
    int r = munmap(ptr, size);
    long long stop = os_now_ns();
    write_log("munmap", r, start, stop);
    return r;
}

int os_pipe_create(int* read_end, int* write_end) {
    int ends[2];
    long long start = os_now_ns();
    int r = pipe(ends);
    long long stop = os_now_ns();
    write_log("pipe", r, start, stop);
    if (r != 0) return -1;
    *read_end = ends[0];
    *write_end = ends[1];
    return 0;
}

int os_shm_open(int key, long size, int create, os_shm* shm) {
    int flags = 0600;
    if (create == 1) flags = IPC_CREAT | 0600;

    long long start = os_now_ns();
    int id = shmget(key, size, flags);
    long long stop = os_now_ns();
    write_log("shmget", id, start, stop);
    if (id < 0) return -1;

    start = os_now_ns();
    void* addr = shmat(id, NULL, 0);
    stop = os_now_ns();
    if (addr == (void*)-1) {
        write_log("shmat", -1, start, stop);
        return -1;
    }
    write_log("shmat", 0, start, stop);
    shm->addr = addr;
    shm->id = id;
    return 0;
}

int os_shm_close(os_shm* shm, int destroy) {
    long long start = os_now_ns();
    int r = shmdt(shm->addr);
    long long stop = os_now_ns();
    write_log("shmdt", r, start, stop);

    if (destroy == 1) {
        start = os_now_ns();
        int r2 = shmctl(shm->id, IPC_RMID, NULL);
        stop = os_now_ns();
        write_log("shmctl_RMID", r2, start, stop);
        if (r2 != 0) r = -1;
    }
    return r;
}

int os_chmod(const char* path, int mode) {
    long long start = os_now_ns();
    int r = chmod(path, mode);
    long long stop = os_now_ns();
    write_log("chmod", r, start, stop);
    return r;
}

int os_chown(const char* path, int uid, int gid) {
    long long start = os_now_ns();
    int r = chown(path, uid, gid);
    long long stop = os_now_ns();
    write_log("chown", r, start, stop);
    return r;
}

int os_umask(int mask) {
    long long start = os_now_ns();
    int old = umask(mask);
    long long stop = os_now_ns();
    write_log("umask", old, start, stop);
    return old;
}

int os_thread_create(void* (*fn)(void*), void* arg, pthread_t* t) {
    long long start = os_now_ns();
    int rc = pthread_create(t, NULL, fn, arg);
    long long stop = os_now_ns();
    if (rc != 0) {
        write_log("pthread_create", -1, start, stop);
        return -1;
    }
    write_log("pthread_create", 0, start, stop);
    return 0;
}

int os_thread_join(pthread_t t) {
    long long start = os_now_ns();
    int rc = pthread_join(t, NULL);
    long long stop = os_now_ns();
    if (rc != 0) {
        write_log("pthread_join", -1, start, stop);
        return -1;
    }
    write_log("pthread_join", 0, start, stop);
    return 0;
}
