#include "os_wrapper.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <algorithm>

FILE* result_file;
FILE* usage_file;

double usage_user_start;
double usage_sys_start;

double micro(long long start, long long stop) {
    return (stop - start) / 1000.0;
}

void report(const char* group, const char* task, const char* native, double* times, int count, int warm) {
    double* list = times + warm;
    int n = count - warm;
    std::sort(list, list + n);

    double sum = 0;
    for (int i = 0; i < n; i++) sum += list[i];
    double mean = sum / n;

    double square_sum = 0;
    for (int i = 0; i < n; i++) square_sum += (list[i] - mean) * (list[i] - mean);
    double sd = sqrt(square_sum / n);

    double median;
    if (n % 2 == 1) median = list[n / 2];
    else median = (list[n / 2 - 1] + list[n / 2]) / 2;

    fprintf(result_file, "%s,%s,%s,%d,%.3f,%.3f,%.3f,%.3f,%.3f\n",
            group, task, native, n, mean, median, list[0], list[n - 1], sd);
    printf("  %-18s %-22s n=%-5d mean=%9.2f  median=%9.2f us\n", task, native, n, mean, median);
}

void usage_start() {
    long kb;
    os_resource_usage(&usage_user_start, &usage_sys_start, &kb);
}

void usage_end(const char* group) {
    double user, sys;
    long kb;
    os_resource_usage(&user, &sys, &kb);
    fprintf(usage_file, "%s,%.2f,%.2f,%ld\n", group, user - usage_user_start, sys - usage_sys_start, kb);
}

void bench_file() {
    printf("\n[File calls]\n");
    usage_start();
    int warm = 3;
    int runs = 100 + warm;
    int big_runs = 50 + warm;
    int mb = 1024 * 1024;
    char* buf = new char[mb];
    memset(buf, 'x', mb);

    os_fd f = os_open("bench_data.bin", OS_WRITE);
    for (int i = 0; i < 4; i++) os_write(f, buf, mb);
    os_close(f);

    double t_open[200], t_close[200], t_w4[200], t_r4[200], t_w1[200], t_r1[200];

    for (int i = 0; i < runs; i++) {
        long long a = os_now_ns();
        os_fd h = os_open("bench_data.bin", OS_READ);
        long long b = os_now_ns();
        os_close(h);
        long long c = os_now_ns();
        t_open[i] = micro(a, b);
        t_close[i] = micro(b, c);
    }

    f = os_open("bench_tmp.bin", OS_WRITE);
    for (int i = 0; i < runs; i++) {
        long long a = os_now_ns();
        os_write(f, buf, 4096);
        t_w4[i] = micro(a, os_now_ns());
    }
    os_close(f);

    f = os_open("bench_data.bin", OS_READ);
    for (int i = 0; i < runs; i++) {
        long long a = os_now_ns();
        os_read(f, buf, 4096);
        t_r4[i] = micro(a, os_now_ns());
    }
    os_close(f);

    for (int i = 0; i < big_runs; i++) {
        f = os_open("bench_tmp.bin", OS_WRITE);
        long long a = os_now_ns();
        os_write(f, buf, mb);
        t_w1[i] = micro(a, os_now_ns());
        os_close(f);
    }

    for (int i = 0; i < big_runs; i++) {
        f = os_open("bench_data.bin", OS_READ);
        long long a = os_now_ns();
        os_read(f, buf, mb);
        t_r1[i] = micro(a, os_now_ns());
        os_close(f);
    }

    report("file", "file_open", "open", t_open, runs, warm);
    report("file", "file_close", "close", t_close, runs, warm);
    report("file", "file_write_4KB", "write", t_w4, runs, warm);
    report("file", "file_read_4KB", "read", t_r4, runs, warm);
    report("file", "file_write_1MB", "write", t_w1, big_runs, warm);
    report("file", "file_read_1MB", "read", t_r1, big_runs, warm);
    usage_end("file");
    delete[] buf;
}

void bench_process() {
    printf("\n[Process calls]  (only 20 runs, creating processes is slow)\n");
    usage_start();
    int warm = 2;
    int runs = 20 + warm;
    double t_create[50], t_wait[50];

    for (int i = 0; i < runs; i++) {
        long long a = os_now_ns();
        int pid = os_spawn("./child", "hello", NULL, NULL);
        long long b = os_now_ns();
        os_wait(pid);
        long long c = os_now_ns();
        t_create[i] = micro(a, b);
        t_wait[i] = micro(b, c);
    }

    report("process", "process_create", "fork(+exec in child)", t_create, runs, warm);
    report("process", "process_wait", "wait", t_wait, runs, warm);
    usage_end("process");
}

void bench_memory() {
    printf("\n[Memory calls]\n");
    usage_start();
    int warm = 3;
    int runs = 100 + warm;
    int big_runs = 50 + warm;
    double a1[200], f1[200], a64[200], f64[200];

    for (int i = 0; i < runs; i++) {
        long long a = os_now_ns();
        void* p = os_mem_alloc(1024 * 1024);
        long long b = os_now_ns();
        os_mem_free(p, 1024 * 1024);
        long long c = os_now_ns();
        a1[i] = micro(a, b);
        f1[i] = micro(b, c);
    }
    for (int i = 0; i < big_runs; i++) {
        long long a = os_now_ns();
        void* p = os_mem_alloc(64 * 1024 * 1024);
        long long b = os_now_ns();
        os_mem_free(p, 64 * 1024 * 1024);
        long long c = os_now_ns();
        a64[i] = micro(a, b);
        f64[i] = micro(b, c);
    }

    report("memory", "mem_alloc_1MB", "mmap", a1, runs, warm);
    report("memory", "mem_free_1MB", "munmap", f1, runs, warm);
    report("memory", "mem_alloc_64MB", "mmap", a64, big_runs, warm);
    report("memory", "mem_free_64MB", "munmap", f64, big_runs, warm);
    usage_end("memory");
}

void bench_ipc() {
    printf("\n[IPC calls]\n");
    usage_start();
    int warm = 3;
    int runs = 100 + warm;
    int shm_runs = 50 + warm;
    double t_create[200], t_write[200], t_read[200], t_close[200], s_open[200], s_close[200];
    char buf[1024];
    memset(buf, 'p', sizeof(buf));

    for (int i = 0; i < runs; i++) {
        int rd, wr;
        long long a = os_now_ns();
        os_pipe_create(&rd, &wr);
        long long b = os_now_ns();
        os_write(wr, buf, 1024);
        long long c = os_now_ns();
        os_read(rd, buf, 1024);
        long long d = os_now_ns();
        os_close(rd);
        os_close(wr);
        long long e = os_now_ns();
        t_create[i] = micro(a, b);
        t_write[i] = micro(b, c);
        t_read[i] = micro(c, d);
        t_close[i] = micro(d, e);
    }

    for (int i = 0; i < shm_runs; i++) {
        os_shm shm;
        long long a = os_now_ns();
        os_shm_open(7001, 1024 * 1024, 1, &shm);
        long long b = os_now_ns();
        os_shm_close(&shm, 1);
        long long c = os_now_ns();
        s_open[i] = micro(a, b);
        s_close[i] = micro(b, c);
    }

    report("ipc", "pipe_create", "pipe", t_create, runs, warm);
    report("ipc", "pipe_write_1KB", "write(pipe)", t_write, runs, warm);
    report("ipc", "pipe_read_1KB", "read(pipe)", t_read, runs, warm);
    report("ipc", "pipe_close_both", "close x2", t_close, runs, warm);
    report("ipc", "shm_create_attach", "shmget+shmat", s_open, shm_runs, warm);
    report("ipc", "shm_detach_remove", "shmdt+shmctl(RMID)", s_close, shm_runs, warm);
    usage_end("ipc");
}

void bench_perm() {
    printf("\n[Permission calls]\n");
    usage_start();
    int warm = 3;
    int runs = 100 + warm;
    double t_chmod[200], t_chown[200], t_umask[200];

    os_fd f = os_open("bench_perm.txt", OS_WRITE);
    os_close(f);

    for (int i = 0; i < runs; i++) {
        long long a = os_now_ns();
        if (i % 2 == 0) os_chmod("bench_perm.txt", 0600);
        else os_chmod("bench_perm.txt", 0644);
        long long b = os_now_ns();
        os_chown("bench_perm.txt", -1, -1);
        long long c = os_now_ns();
        os_umask(022);
        long long d = os_now_ns();
        t_chmod[i] = micro(a, b);
        t_chown[i] = micro(b, c);
        t_umask[i] = micro(c, d);
    }

    report("permissions", "perm_chmod", "chmod", t_chmod, runs, warm);
    report("permissions", "perm_chown", "chown", t_chown, runs, warm);
    report("permissions", "perm_umask", "umask", t_umask, runs, warm);
    usage_end("permissions");
    os_chmod("bench_perm.txt", 0600);
    remove("bench_perm.txt");
}

int main() {
    printf("Benchmark on linux\n");
    result_file = fopen("bench_linux.csv", "w");
    usage_file = fopen("bench_resources_linux.csv", "w");
    if (result_file == NULL || usage_file == NULL) {
        printf("cannot create the output files\n");
        return 1;
    }
    fprintf(result_file, "group,task,native_call,iterations,mean_us,median_us,min_us,max_us,stddev_us\n");
    fprintf(usage_file, "group,cpu_user_ms,cpu_sys_ms,peak_mem_kb\n");

    bench_file();
    bench_process();
    bench_memory();
    bench_ipc();
    bench_perm();

    fclose(result_file);
    fclose(usage_file);
    remove("bench_data.bin");
    remove("bench_tmp.bin");
    printf("\nSaved bench_linux.csv and bench_resources_linux.csv\n");
    return 0;
}
