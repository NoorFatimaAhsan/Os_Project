#ifndef OS_WRAPPER_H
#define OS_WRAPPER_H

#include <windows.h>

typedef HANDLE os_fd;
#define OS_BAD_FD INVALID_HANDLE_VALUE
typedef HANDLE os_thread;

#define OS_READ      0
#define OS_WRITE     1
#define OS_APPEND    2
#define OS_READWRITE 3

struct os_shm {
    void*  addr;
    int    id;
    HANDLE handle;
};

long long os_now_ns();

int os_resource_usage(double* user_ms, double* sys_ms, long* peak_mem_kb);

int os_log_open(const char* path);

void os_log_close();

os_fd os_open(const char* path, int mode);

long os_read(os_fd fd, void* buf, long n);

long os_write(os_fd fd, const void* buf, long n);

int os_close(os_fd fd);

int os_spawn(const char* program, const char* arg1, const char* arg2, const char* arg3);

int os_wait(int pid);

void* os_mem_alloc(long size);

int os_mem_free(void* ptr, long size);

int os_pipe_create(os_fd* read_end, os_fd* write_end);

int os_shm_open(int key, long size, int create, os_shm* shm);

int os_shm_close(os_shm* shm, int destroy);

int os_chmod(const char* path, int mode);

int os_chown(const char* path, int uid, int gid);

int os_umask(int mask);

int os_thread_create(DWORD (WINAPI *fn)(LPVOID), void* arg, os_thread* t);

int os_thread_join(os_thread t);

#endif
