#include "os_wrapper.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int fails = 0;

void check(const char* what, int ok) {
    if (ok) printf("  [PASS] %s\n", what);
    else {
        printf("  [FAIL] %s\n", what);
        fails++;
    }
}

void demo_file() {
    printf("\n== File calls ==\n");
    int size = 1000000;
    char* out = new char[size];
    char* in = new char[size];
    for (int i = 0; i < size; i++) out[i] = 'A' + i % 26;

    os_fd f = os_open("demo_file.bin", OS_WRITE);
    check("create the file", f != OS_BAD_FD);
    check("write 1,000,000 bytes", os_write(f, out, size) == size);
    check("close the file", os_close(f) == 0);

    f = os_open("demo_file.bin", OS_APPEND);
    check("append 5 bytes", os_write(f, "tail!", 5) == 5);
    os_close(f);

    f = os_open("demo_file.bin", OS_READ);
    check("read the data back", os_read(f, in, size) == size);
    check("data is the same as written", memcmp(in, out, size) == 0);
    os_close(f);

    check("opening a missing file fails", os_open("no_such_file.bin", OS_READ) == OS_BAD_FD);

    remove("demo_file.bin");
    delete[] out;
    delete[] in;
}

void demo_perm() {
    printf("\n== Permission calls ==\n");
    int old_mask = os_umask(0);
    printf("  old umask was %o\n", old_mask);
    os_fd f = os_open("demo_perm.txt", OS_WRITE);
    os_write(f, "secret", 6);
    os_close(f);
    os_umask(old_mask);

    check("chmod 0400 (owner can only read)", os_chmod("demo_perm.txt", 0400) == 0);
    os_fd w = os_open("demo_perm.txt", OS_WRITE);
    if (w == OS_BAD_FD) printf("  writing is BLOCKED, so the permission works\n");
    else {
        printf("  writing was allowed (are you running as administrator?)\n");
        os_close(w);
    }

    check("chown (owner = the user who runs us)", os_chown("demo_perm.txt", -1, -1) == 0);
    check("chmod 0600 (so we can delete it)", os_chmod("demo_perm.txt", 0600) == 0);
    remove("demo_perm.txt");
}

void demo_memory() {
    printf("\n== Memory calls ==\n");
    long size = 4 * 1024 * 1024;
    char* m = (char*)os_mem_alloc(size);
    check("allocate 4 MB", m != NULL);
    if (m == NULL) return;

    m[0] = 'A';
    m[size - 1] = 'Z';
    check("memory can be used", m[0] == 'A' && m[size - 1] == 'Z');
    check("free the memory", os_mem_free(m, size) == 0);
}

void demo_process() {
    printf("\n== Process calls ==\n");
    int pid = os_spawn(".\\child.exe", "hello", NULL, NULL);
    check("start the child process", pid > 0);
    int code = os_wait(pid);
    printf("  the child ended with exit code %d (we expect 7)\n", code);
    check("exit code is 7", code == 7);
}

void demo_ipc() {
    printf("\n== IPC calls ==\n");

    os_fd read_end, write_end;
    check("create a pipe", os_pipe_create(&read_end, &write_end) == 0);
    char number[20];
    sprintf(number, "%llu", (unsigned long long)write_end);
    int pid = os_spawn(".\\child.exe", "pipe", number, NULL);
    check("start the child with the pipe", pid > 0);
    os_close(write_end);
    char buf[100] = {0};
    long n = os_read(read_end, buf, 99);
    printf("  received %ld bytes: \"%s\"\n", n, buf);
    check("message came through the pipe", n > 0 && strstr(buf, "via pipe") != NULL);
    os_wait(pid);
    os_close(read_end);

    os_shm shm;
    check("create shared memory", os_shm_open(5151, 4096, 1, &shm) == 0);
    memset(shm.addr, 0, 4096);
    pid = os_spawn(".\\child.exe", "shm", "5151", "4096");
    check("start the child with shared memory", pid > 0);
    os_wait(pid);
    printf("  we read from shared memory: \"%s\"\n", (char*)shm.addr);
    check("child's message is in shared memory", strstr((char*)shm.addr, "via shared memory") != NULL);
    check("delete the shared memory", os_shm_close(&shm, 1) == 0);
}

DWORD WINAPI thread_work(LPVOID arg) {
    int* result = (int*)arg;
    *result = 42;
    return 0;
}

void demo_thread() {
    printf("\n== Thread calls ==\n");
    int result = 0;
    os_thread t;
    check("start a thread", os_thread_create(thread_work, &result, &t) == 0);
    check("wait for the thread", os_thread_join(t) == 0);
    printf("  the thread wrote %d (we expect 42)\n", result);
    check("thread result is 42", result == 42);
}

int main(int argc, char* argv[]) {
    const char* which = "all";
    if (argc > 1) which = argv[1];

    os_log_open("demo_log.csv");

    if (strcmp(which, "all") == 0 || strcmp(which, "file") == 0)    demo_file();
    if (strcmp(which, "all") == 0 || strcmp(which, "perm") == 0)    demo_perm();
    if (strcmp(which, "all") == 0 || strcmp(which, "memory") == 0)  demo_memory();
    if (strcmp(which, "all") == 0 || strcmp(which, "process") == 0) demo_process();
    if (strcmp(which, "all") == 0 || strcmp(which, "ipc") == 0)     demo_ipc();
    if (strcmp(which, "all") == 0 || strcmp(which, "thread") == 0)  demo_thread();

    os_log_close();
    if (fails == 0) printf("\nALL CHECKS PASSED. See demo_log.csv\n");
    else printf("\n%d CHECK(S) FAILED\n", fails);
    return fails;
}
