#include "os_wrapper.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <psapi.h>

FILE* log_file = NULL;

long long os_now_ns() {
    LARGE_INTEGER frequency, counter;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&counter);
    long long seconds = counter.QuadPart / frequency.QuadPart;
    long long rest = counter.QuadPart % frequency.QuadPart;
    return seconds * 1000000000LL + rest * 1000000000LL / frequency.QuadPart;
}

int os_log_open(const char* path) {
    log_file = fopen(path, "a");
    if (log_file == NULL) return -1;
    fseek(log_file, 0, SEEK_END);
    if (ftell(log_file) == 0)
        fprintf(log_file, "call,status,result,error,time_us\n");
    return 0;
}

void os_log_close() {
    if (log_file != NULL) {
        fclose(log_file);
        log_file = NULL;
    }
}

void write_log(const char* name, long result, long long start, long long stop) {
    if (log_file == NULL) return;
    int error = 0;
    if (result < 0) error = GetLastError();
    fprintf(log_file, "%s,%s,%ld,%d,%.3f\n",
            name,
            result < 0 ? "FAIL" : "OK",
            result,
            error,
            (stop - start) / 1000.0);
    fflush(log_file);
}

int os_resource_usage(double* user_ms, double* sys_ms, long* peak_mem_kb) {
    FILETIME create_time, exit_time, kernel_time, user_time;
    if (!GetProcessTimes(GetCurrentProcess(), &create_time, &exit_time, &kernel_time, &user_time)) return -1;
    ULARGE_INTEGER k, u;
    k.LowPart = kernel_time.dwLowDateTime;  k.HighPart = kernel_time.dwHighDateTime;
    u.LowPart = user_time.dwLowDateTime;    u.HighPart = user_time.dwHighDateTime;
    *sys_ms = k.QuadPart / 10000.0;
    *user_ms = u.QuadPart / 10000.0;
    PROCESS_MEMORY_COUNTERS memory;
    if (!GetProcessMemoryInfo(GetCurrentProcess(), &memory, sizeof(memory))) return -1;
    *peak_mem_kb = (long)(memory.PeakWorkingSetSize / 1024);
    return 0;
}

os_fd os_open(const char* path, int mode) {
    DWORD access = GENERIC_READ;
    DWORD how = OPEN_EXISTING;
    if (mode == OS_WRITE)     { access = GENERIC_WRITE;                 how = CREATE_ALWAYS; }
    if (mode == OS_APPEND)    { access = FILE_APPEND_DATA;              how = OPEN_ALWAYS; }
    if (mode == OS_READWRITE) { access = GENERIC_READ | GENERIC_WRITE;  how = OPEN_ALWAYS; }

    long long start = os_now_ns();
    HANDLE h = CreateFileA(path, access, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, how, FILE_ATTRIBUTE_NORMAL, NULL);
    long long stop = os_now_ns();
    if (h == INVALID_HANDLE_VALUE) write_log("CreateFile", -1, start, stop);
    else write_log("CreateFile", 0, start, stop);
    return h;
}

long os_read(os_fd fd, void* buf, long n) {
    DWORD got = 0;
    long long start = os_now_ns();
    BOOL ok = ReadFile(fd, buf, n, &got, NULL);
    long long stop = os_now_ns();
    if (!ok && GetLastError() == ERROR_BROKEN_PIPE) {
        ok = TRUE;
        got = 0;
    }
    if (!ok) {
        write_log("ReadFile", -1, start, stop);
        return -1;
    }
    write_log("ReadFile", got, start, stop);
    return got;
}

long os_write(os_fd fd, const void* buf, long n) {
    DWORD put = 0;
    long long start = os_now_ns();
    BOOL ok = WriteFile(fd, buf, n, &put, NULL);
    long long stop = os_now_ns();
    if (!ok) {
        write_log("WriteFile", -1, start, stop);
        return -1;
    }
    write_log("WriteFile", put, start, stop);
    return put;
}

int os_close(os_fd fd) {
    long long start = os_now_ns();
    BOOL ok = CloseHandle(fd);
    long long stop = os_now_ns();
    if (!ok) {
        write_log("CloseHandle", -1, start, stop);
        return -1;
    }
    write_log("CloseHandle", 0, start, stop);
    return 0;
}

HANDLE processes[1000];
int process_count = 0;

int os_spawn(const char* program, const char* arg1, const char* arg2, const char* arg3) {
    char text[500];
    strcpy(text, program);
    if (arg1 != NULL) { strcat(text, " "); strcat(text, arg1); }
    if (arg2 != NULL) { strcat(text, " "); strcat(text, arg2); }
    if (arg3 != NULL) { strcat(text, " "); strcat(text, arg3); }

    STARTUPINFOA startup;
    PROCESS_INFORMATION info;
    memset(&startup, 0, sizeof(startup));
    startup.cb = sizeof(startup);
    memset(&info, 0, sizeof(info));

    long long start = os_now_ns();
    BOOL ok = CreateProcessA(NULL, text, NULL, NULL, TRUE, 0, NULL, NULL, &startup, &info);
    long long stop = os_now_ns();
    if (!ok || process_count >= 1000) {
        write_log("CreateProcess", -1, start, stop);
        return -1;
    }
    write_log("CreateProcess", 0, start, stop);
    CloseHandle(info.hThread);
    processes[process_count] = info.hProcess;
    process_count++;
    return process_count;
}

int os_wait(int pid) {
    if (pid < 1 || pid > process_count) return -1;
    HANDLE h = processes[pid - 1];
    long long start = os_now_ns();
    DWORD r = WaitForSingleObject(h, INFINITE);
    long long stop = os_now_ns();
    if (r != WAIT_OBJECT_0) {
        write_log("WaitForSingleObject", -1, start, stop);
        return -1;
    }
    write_log("WaitForSingleObject", 0, start, stop);
    DWORD exit_code = 0;
    GetExitCodeProcess(h, &exit_code);
    CloseHandle(h);
    return (int)exit_code;
}

void* os_mem_alloc(long size) {
    long long start = os_now_ns();
    void* p = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    long long stop = os_now_ns();
    if (p == NULL) write_log("VirtualAlloc", -1, start, stop);
    else write_log("VirtualAlloc", 0, start, stop);
    return p;
}

int os_mem_free(void* ptr, long size) {
    (void)size;
    long long start = os_now_ns();
    BOOL ok = VirtualFree(ptr, 0, MEM_RELEASE);
    long long stop = os_now_ns();
    if (!ok) {
        write_log("VirtualFree", -1, start, stop);
        return -1;
    }
    write_log("VirtualFree", 0, start, stop);
    return 0;
}

int os_pipe_create(os_fd* read_end, os_fd* write_end) {
    SECURITY_ATTRIBUTES attributes;
    attributes.nLength = sizeof(attributes);
    attributes.lpSecurityDescriptor = NULL;
    attributes.bInheritHandle = TRUE;
    long long start = os_now_ns();
    BOOL ok = CreatePipe(read_end, write_end, &attributes, 0);
    long long stop = os_now_ns();
    if (!ok) {
        write_log("CreatePipe", -1, start, stop);
        return -1;
    }
    write_log("CreatePipe", 0, start, stop);
    return 0;
}

int os_shm_open(int key, long size, int create, os_shm* shm) {
    char name[60];
    sprintf(name, "Local\\cca_shm_%d", key);

    long long start = os_now_ns();
    HANDLE h;
    if (create == 1) h = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, size, name);
    else             h = OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, name);
    long long stop = os_now_ns();
    if (h == NULL) {
        write_log(create == 1 ? "CreateFileMapping" : "OpenFileMapping", -1, start, stop);
        return -1;
    }
    write_log(create == 1 ? "CreateFileMapping" : "OpenFileMapping", 0, start, stop);

    start = os_now_ns();
    void* addr = MapViewOfFile(h, FILE_MAP_ALL_ACCESS, 0, 0, size);
    stop = os_now_ns();
    if (addr == NULL) {
        write_log("MapViewOfFile", -1, start, stop);
        CloseHandle(h);
        return -1;
    }
    write_log("MapViewOfFile", 0, start, stop);
    shm->addr = addr;
    shm->id = key;
    shm->handle = h;
    return 0;
}

int os_shm_close(os_shm* shm, int destroy) {
    (void)destroy;
    long long start = os_now_ns();
    BOOL ok = UnmapViewOfFile(shm->addr);
    long long stop = os_now_ns();
    if (!ok) write_log("UnmapViewOfFile", -1, start, stop);
    else write_log("UnmapViewOfFile", 0, start, stop);
    CloseHandle(shm->handle);
    return ok ? 0 : -1;
}

TOKEN_USER* get_my_user() {
    HANDLE token;
    DWORD size = 0;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) return NULL;
    GetTokenInformation(token, TokenUser, NULL, 0, &size);
    TOKEN_USER* user = (TOKEN_USER*)malloc(size);
    if (user == NULL || !GetTokenInformation(token, TokenUser, user, size, &size)) {
        free(user);
        CloseHandle(token);
        return NULL;
    }
    CloseHandle(token);
    return user;
}

int os_chmod(const char* path, int mode) {
    TOKEN_USER* user = get_my_user();
    if (user == NULL) return -1;

    DWORD rights = 0;
    if (mode & 0400) rights = rights | FILE_GENERIC_READ;
    if (mode & 0200) rights = rights | FILE_GENERIC_WRITE | DELETE;
    if (mode & 0100) rights = rights | FILE_GENERIC_EXECUTE;

    DWORD acl_size = sizeof(ACL) + sizeof(ACCESS_ALLOWED_ACE) + GetLengthSid(user->User.Sid);
    ACL* acl = (ACL*)malloc(acl_size);
    InitializeAcl(acl, acl_size, ACL_REVISION);
    AddAccessAllowedAce(acl, ACL_REVISION, rights, user->User.Sid);

    SECURITY_DESCRIPTOR descriptor;
    InitializeSecurityDescriptor(&descriptor, SECURITY_DESCRIPTOR_REVISION);
    SetSecurityDescriptorDacl(&descriptor, TRUE, acl, FALSE);

    long long start = os_now_ns();
    BOOL ok = SetFileSecurityA(path, DACL_SECURITY_INFORMATION, &descriptor);
    long long stop = os_now_ns();
    if (!ok) write_log("SetFileSecurity", -1, start, stop);
    else write_log("SetFileSecurity", 0, start, stop);
    free(acl);
    free(user);
    return ok ? 0 : -1;
}

int os_chown(const char* path, int uid, int gid) {
    (void)uid;
    (void)gid;
    TOKEN_USER* user = get_my_user();
    if (user == NULL) return -1;

    SECURITY_DESCRIPTOR descriptor;
    InitializeSecurityDescriptor(&descriptor, SECURITY_DESCRIPTOR_REVISION);
    SetSecurityDescriptorOwner(&descriptor, user->User.Sid, FALSE);

    long long start = os_now_ns();
    BOOL ok = SetFileSecurityA(path, OWNER_SECURITY_INFORMATION, &descriptor);
    long long stop = os_now_ns();
    if (!ok) write_log("SetFileSecurity(owner)", -1, start, stop);
    else write_log("SetFileSecurity(owner)", 0, start, stop);
    free(user);
    return ok ? 0 : -1;
}

int saved_mask = 022;

int os_umask(int mask) {
    long long start = os_now_ns();
    int old = saved_mask;
    saved_mask = mask;
    long long stop = os_now_ns();
    write_log("umask(emulated)", old, start, stop);
    return old;
}

int os_thread_create(DWORD (WINAPI *fn)(LPVOID), void* arg, os_thread* t) {
    long long start = os_now_ns();
    HANDLE h = CreateThread(NULL, 0, fn, arg, 0, NULL);
    long long stop = os_now_ns();
    if (h == NULL) {
        write_log("CreateThread", -1, start, stop);
        return -1;
    }
    write_log("CreateThread", 0, start, stop);
    *t = h;
    return 0;
}

int os_thread_join(os_thread t) {
    long long start = os_now_ns();
    DWORD r = WaitForSingleObject(t, INFINITE);
    long long stop = os_now_ns();
    CloseHandle(t);
    if (r != WAIT_OBJECT_0) {
        write_log("WaitForSingleObject(thread)", -1, start, stop);
        return -1;
    }
    write_log("WaitForSingleObject(thread)", 0, start, stop);
    return 0;
}
